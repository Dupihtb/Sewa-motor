-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2023 at 05:09 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sewamotor`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(250) NOT NULL,
  `akses` varchar(20) NOT NULL,
  `id_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Id`, `username`, `password`, `akses`, `id_user`) VALUES
(7, 'admin', '1234', 'admin', NULL),
(9, 'Dupi', '1234', 'member', 4),
(10, 'ksty', '1234', 'member', 7);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `jumlah_produk` int(11) DEFAULT NULL,
  `detail_produk` varchar(250) DEFAULT NULL,
  `harga_sewa` int(11) DEFAULT NULL,
  `gambar_produk` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `jumlah_produk`, `detail_produk`, `harga_sewa`, `gambar_produk`) VALUES
(3, 'Vario 150', 12, 'Vario Terbaru', 170000, 'vario 150.jpg'),
(4, 'PCX 160', 20, 'Motor Terbaru', 200000, 'pcx 160.png'),
(6, 'Revo Vit', 10, 'Nyaman di gunakan', 100000, 'Revo.png'),
(7, 'Matic', 20, 'Matic terbaru', 100000, 'matic.jpg'),
(8, 'Vixion', 10, 'Motor terbaru', 100000, 'vixion.png'),
(9, 'Beat', 10, 'Nyaman digunakan', 800000, 'beat..jpg'),
(11, 'Vario 150', 12, 'Nyaman di gunakan', 200000, 'VARIO 125.jpg'),
(12, 'Scoopy 125', 12, 'Nyaman di gunakan ', 100000, 'Soopy 125.jpeg'),
(14, 'Genio', 20, 'Genio Terbaru', 150000, 'genio.png');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal_sewa` date DEFAULT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `harga_total` float DEFAULT NULL,
  `tgl_transaksi` datetime DEFAULT NULL,
  `metode_pembayaran` varchar(20) DEFAULT NULL,
  `status_transaksi` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_produk`, `id_user`, `tanggal_sewa`, `tgl_pengembalian`, `harga_total`, `tgl_transaksi`, `metode_pembayaran`, `status_transaksi`) VALUES
(10, 4, 6, '2023-07-13', '2023-07-20', 400000, '2023-07-03 04:48:48', 'transfer', 'proses'),
(11, 6, 6, '2023-07-19', '2023-07-27', 200000, '2023-07-03 04:52:58', 'transfer', 'proses'),
(12, 4, 4, '2023-07-21', '2023-07-23', 400000, '2023-07-03 04:54:28', 'transfer', 'berlangsung'),
(13, 3, 7, '2023-07-05', '2023-07-10', 340000, '2023-07-03 05:00:12', 'transfer', 'berlangsung');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_depan` varchar(20) DEFAULT NULL,
  `nama_belakang` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `no_telpon` varchar(20) DEFAULT NULL,
  `jenis_kelamin` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_depan`, `nama_belakang`, `email`, `no_telpon`, `jenis_kelamin`) VALUES
(4, 'Dupi', 'Hutabarat', 'dupihutabarat@gmail.com', '081265437865', 'P'),
(7, 'ksty', 'ksty', 'ksty@gmail.com', '08217879700', 'L');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
