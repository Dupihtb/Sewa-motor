<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Input Berkas</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
  <body>    

    <nav class="navbar navbar-expand-lg">
            <div class="container">
                <div class="d-flex align-item-center">
                    <!-- <img src="img/logo.png" alt="" class="nav-logo"> -->
                    <a href="#" class="navbar-brand">Penyewaan Motor</a>
                </div>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
                        <a href="home.php" class="nav-item nav-link text-white active"><i class='icon bx bx-home-alt-2' ></i> Home</a>
                        <a class="btn nav-login nav-item nav-link" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class='icon bx bx-user'></i> Login</a>
                    </div>
                </div>
            </div>
        </nav>

    <div class="wrapper-login">
        <div class="kotak_register">
            <form action="proses/proses_register.php" method="post">
                <h5>Akun</h5>
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Username</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="username" required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Password</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="password" required>
                    </div>
                </div>
                
                <div class="form-group row">
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-8">
                        <small class="text-danger">Perhatikan :</small><br>
                        <small class="text-danger">1. Catet username dan password saat melakukan pendaftaran</small><br>
                        <small class="text-danger">2. Gunakan username dan password saat mendaftar untuk login dan melihat status pendaftaran</small><br>
                        <small class="text-danger">3. Lengkapi berkas yang sudah ditentukan</small><br>
                    </div>
                </div>

                <h5>Biodata</h5>
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Nama Depan</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="nama_depan" required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Nama Belakang</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="nama_belakang" required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>No Telpon</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="no_telpon" required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Email</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="email" name="email" required>
                    </div>
                </div>
                
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>Jenis Kelamin</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="form-control" type="text" name="jenis_kelamin" required>
                    </div>
                </div>

                
               

              

                <!-- UPLOAD BERKAS -->
                <!-- <h5>Form Berkas</h5>
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label>File Berkas</label>
                    </div>

                    <div class="col-sm-8">
                        <input class="KIP form-control" type="file" name="file_berkas" accept=".pdf">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                    </div>

                    <div class="col-sm-8">
                        <small class="text-danger">Perhatikan :</small><br>
                        <small class="text-danger">1. File digabung menjadi 1 file dan disimpan dalam bentuk .pdf</small><br>
                        <small class="text-danger">2. Ukuran file maksimal 1 mb</small><br>
                        <small class="text-danger">3. Urutan file disusun sebagai berikut :</small><br>
                        <small class="text-danger">- Formulir KIP</small><br>
                        <small class="text-danger">- Kartu Peserta KIP</small><br>
                        <small class="text-danger">- Ijazah atau Surat Keterangan Lulus (SKL)</small><br>
                        <small class="text-danger">- Scan Rapor semester 1 - 5</small><br>
                        <small class="text-danger">- Surat Keterangan Tidak Mampu</small><br>
                        <small class="text-danger">- Surat Keterangan Penghasilan Orang Tua</small><br>
                        <small class="text-danger">- Scan Sertifikat Prestasi (Harus di sesuaikan dengan jumlah prestasi yang diinputkan)</small><br>
                        <small class="text-danger">- Scan struk pembayaran listrik 3 bulan terakhir</small><br>
                        <small class="text-danger">- Photo Rumah</small><br>
                        <small class="text-danger">- Pas Foto Formal</small><br>
                    </div>
                </div> -->

                <center><button type="submit" class="button-submit btn" name="btnregister">Submit</button></center>
            </form>
        </div>
    </div>


      <!-- Modal -->
      <div class="modal fade" id="staticBackdrop" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                <div class="modal-header text-center">
                   <center><h5 class="modal-title text-white" id="staticBackdropLabel">Login</h5></center> 
                </div>
                <div class="modal-body">
                     <section id="form-login">
                        <div class="login">
                            <div>
                                <form action="proses/proses_login.php" method="post">
                                    <div class="header-login">
                                        <img src="img/logo.png" alt="" style="width:100px">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="">Username</label>
                                        <input type="text" class="form-control" name="username" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="">Password</label>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>

                                    <div class="form-button">
                                        <button class="btn-login btn" type="submit" name="Submit">Login</button>
                                    </div>

                                    <div class="form-link">
                                        <span><a href="" class="forgot-password">Forgot password?</a> | <a href="register.php" class="link-register">Register</a></span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
                </div>
            </div>
        </div>
    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>
</html>