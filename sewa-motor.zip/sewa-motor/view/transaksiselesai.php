<?php 
include "../dataacces/config.php";

if (!$_SESSION["logged"]) {
    header("location:../home.php");
}

$user = $_SESSION["username"];

$viewLogin = "SELECT id_user FROM login WHERE login.username = '$user'";
$result2 = mysqli_query($koneksi, $viewLogin);
$row = mysqli_fetch_array($result2); 
$idUser = $row["id_user"];


if($_SESSION["akses"] != 1)
{
    echo "<script>alert('Hanya admin yang memiliki Akses')</script>";
    echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
}
else if($_SESSION["akses"] = 1)
{
    $hasil = getAllTransaksi($koneksi);
}



function getAllTransaksi($koneksi){
    $viewKriteria = "SELECT *
    FROM ((transaksi
    INNER JOIN produk ON produk.id_produk = transaksi.id_produk)
    INNER JOIN user ON user.id_user = transaksi.id_user) where status_transaksi='selesai'";
    $hasil = mysqli_query($koneksi, $viewKriteria);
    return $hasil;
}


$result = $hasil;



?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <title>Transaksi Selesai | Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <script src="../script.js"></script>

</head>
<body>    
    
    
<nav class="navbar navbar-expand-lg">
            <div class="container">
                <div class="d-flex align-item-center">
                    <!-- <img src="../img/logo.png" alt="" class="nav-logo"> -->
                    <a href="#" class="navbar-brand">Penyewaan Motor</a>
                </div>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
                    <?php 
                    if($_SESSION["akses"] == 1)
                    {
                    ?>
                        <a href="member.php" class="nav-item nav-link"><i class='icon bx bx-user' ></i> Member</a>
                        <a href="produk.php" class="nav-item nav-link"><i class='bx bxs-camera'></i> Produk</a>

                        <a href="daftartransaksi.php" class="nav-item nav-link active"><i class='bx bx-list-ul'></i> Daftar Transaksi</a>
                        <a href="laporan.php" class="nav-item nav-link"><i class='icon bx bx-book' ></i> Laporan</a>
                    <?php }else if($_SESSION["akses"] == 2){?>
                        
                        <a href="index.php" class="nav-item nav-link"><i class='icon bx bx-home-alt-2' ></i> Home</a>
                        <a href="daftartransaksi.php" class="nav-item nav-link active"><i class='bx bx-list-ul'></i> Daftar Transaksi</a>
                        <?php }?>
                        <a href="../proses/proses_logout.php" class="btn nav-login nav-item nav-link d-flex align-items-center"><small>Logout</small><i class='icon bx bx-log-in-circle'></i></a>
                    </div>
                </div>
            </div>
        </nav>

        
        <div class="container">
            
            <div class="alert alert-light mt-4 d-flex justify-content-between align-items-center" role="alert">
                <div class="d-flex align-items-center">
                    <i class='bx bxs-camera-plus icon' style="font-size:50px; margin-right:10px" ></i>
                    <h5><span style="color:blue; font-weight:bold;">Penyewaan </span> Motor </h5>
                </div>
                <div class="d-flex align-items-center">
                    <i class='bx bx-time icon' style="font-size:20px; margin-right:10px"></i> 
                    <span id="date_time"></span>
                </div>
            </div>

           
            <div class="card mt-2">
                <div class="btn-group mb-3" role="group" aria-label="Basic example" style="width:300px; margin:20px">
                    <a href="daftartransaksi.php" type="button" class="btn btn-primary">Proses</a>
                    <a href="transaksiberlangsung.php" type="button" class="btn btn-primary">Berlangsung</a>
                    <a href="transaksiselesai.php" class="btn btn-primary">Selesai</a>
                </div>
                <h3 class="mt-3 mr-5" style="margin-left:20px"><span class="text-primary">Tabel</span> Transaksi Selesai</h3>
                <div class="card-body">
                    <table id="tabel-data" class="table table-bordered table-danger table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th style="text-align: right;">Produk</th>
                                <th style="text-align: right;">Peminjam</th>
                                <th style="text-align: right;">Tanggal Sewa</th>
                                <th style="text-align: right;">Tanggal Pengembalian</th>
                                <th style="text-align: center;">Total Pembayaran</th>
                                <th style="text-align: center;">Pembayaran</th>
                                <th style="text-align: right;">Proses</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php 
                            $noUrut = 1;
                            while($data = mysqli_fetch_array($result)){
                        ?>
                             <tr>
                                <td><?php echo $noUrut++; ?></td>
                                <td style="text-align: right;"><?php echo $data["nama_produk"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["nama_depan"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["tanggal_sewa"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["tgl_pengembalian"]; ?></td>                                
                                <td style="text-align: center;"><?php echo $data["harga_total"]; ?></td>
                                <td style="text-align: center;"><?php echo $data["metode_pembayaran"]; ?></td>
                                <td style="text-align: center;"><?php echo $data["status_transaksi"]; ?></td>
                                
                                    
                                </td>
                            </tr>
                        <?php 
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
              </div>
        </div>

    
        
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script>
            $(document).ready(function(){
                $('#tabel-data').DataTable();
            });
        </script>
        <script type="text/javascript">window.onload = date_time('date_time');</script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="script.js"></script>
    </body>
    </html>