<?php
include "../dataacces/config.php";
error_reporting(0);
if (!$_SESSION["logged"]) {
    header("location:../home.php");
}


?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <title>Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <script src="../script.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>

<body style="background-color:white">

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <div class="d-flex align-item-center">
                <!-- <img src="../img/logo.png" alt="" class="nav-logo"> -->
                <a href="#" class="navbar-brand">Penyewaan Motor</a>
            </div>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">

                    <a href="index.php" class="nav-item nav-link"><i class='icon bx bx-home-alt-2'></i> Home</a>

                    <a href="../proses/proses_logout.php" class="btn nav-login nav-item nav-link d-flex align-items-center"><small>Logout</small><i class='icon bx bx-log-in-circle'></i></a>
                </div>
            </div>
        </div>
    </nav>
    <?php
    if (isset($_POST['btnnext'])) {
        $id = $_POST["id_produk"];
        $idUser = $_POST["id_user"];
        $tglpinjam = $_POST["tgl_pinjam"];
        $tglbalik = $_POST["tgl_pengembalian"];
        $harga = $_POST["harga"];
        $durasi = $_POST["durasipinjam"];
        $pembayaran = $_POST["pembayaran"];
        $totalbayar = $harga * $durasi;
    ?>

        <div class="mt-5 container text-center">
            <div class="row g-2 d-flex justify-content-center">
                <div class="mt-3 mb-3">
                    <span style="font-size:30px" class="text-primary">Form Konfirmasi</span>
                </div>
                <div class="col-6">
                    <div class="p-3 bg-white">

                        <form action="../proses/proses_transaksi.php" meethod="post">
                            <div style="padding:20px" class="">
                                <input type="hidden" class="form-control" value="<?php echo $idUser; ?>" name="id_user">
                                <input type="hidden" class="form-control" value="<?php echo $id; ?>" name="id_produk">
                                <input type="hidden" class="form-control" value="<?php echo $tglpinjam; ?>" name="tgl_pinjam">
                                <input type="hidden" class="form-control" value="<?php echo $tglbalik; ?>" name="tgl_pengembalian">
                                <input type="hidden" class="form-control" value="<?php echo $totalbayar; ?>" name="total_bayar">
                                <input type="hidden" value="<?php echo $pembayaran; ?>" name="pembayaran">
                                <?php
                                $viewTingkatKepentingan = "SELECT * FROM produk where id_produk = $id";
                                $result = mysqli_query($koneksi, $viewTingkatKepentingan);
                                while ($data = mysqli_fetch_array($result)) {
                                ?>

                                    <img src="../uploads/<?php echo $data["gambar_produk"]; ?> " alt="" style="width:200px">
                                    <p style="font-weight:bold"><?php echo $data["nama_produk"]; ?> </p>
                                    <p>Tanggal Pinjam : <?php echo $tglpinjam ?></p>
                                    <p>Tanggal Pengembalian : <?php echo $tglbalik ?></p>
                                    <p>Durasi : <?php echo $durasi ?> hari</p>
                                    <p class="">Harga Sewa: Rp. <?php echo $data["harga_sewa"]; ?> /hari</p>
                                    <p class="text-danger">Total Bayar: Rp. <?php echo $totalbayar; ?> /hari</p>
                                    <p>Jenis Pembayaran : <?php echo $pembayaran; ?></p>
                                    <?php if ($pembayaran == 'cash') {
                                        $print = "Lakukan pembayaran ditempat pada saat pengambilan motor.";
                                    } else {
                                        $print = "Transfer ke Mandiri a.n Dupi Salvanera Hutabarat <b>1678900090</b><br>
                                                      <small>*Tunjukkan bukti transfer pada saat pengambilan motor.</small>   
                                                     ";
                                    } ?>

                                    <p><?php echo $print; ?></p>
                                    <button class="btn btn-block btn-primary mt-3" type="submit" name="btnkonfirmasi">Konfirmasi</button>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>


<!-- Option 1: Bootstrap Bundle with Popper -->
<script>
    $(document).ready(function() {
        $('#tabel-data').DataTable();
    });
</script>
<script type="text/javascript">
    window.onload = date_time('date_time');
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="script.js"></script>
</body>

</html>