<?php
include "../dataacces/config.php";

if (!$_SESSION["logged"]) {
    header("location:../home.php");
}

$user = $_SESSION["username"];
$viewLogin = "SELECT id_user FROM login WHERE login.username = '$user'";
$result2 = mysqli_query($koneksi, $viewLogin);
$row = mysqli_fetch_array($result2);
$idUser = $row["id_user"];



$viewTingkatKepentingan = "SELECT * FROM produk";
$result = mysqli_query($koneksi, $viewTingkatKepentingan);
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <title>Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <script src="../script.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <div class="d-flex align-item-center">
                <!-- <img src="../img/logo.png" alt="" class="nav-logo"> -->
                <a href="#" class="navbar-brand">Penyewaan Motor</a>
            </div>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">
                    <?php
                    if ($_SESSION["akses"] == 1) {
                    ?>
                        <a href="member.php" class="nav-item nav-link"><i class='icon bx bx-user'></i> Member</a>
                        <a href="produk.php" class="nav-item nav-link"><i class='bx bxs-camera'></i> Produk</a>

                        <a href="daftartransaksi.php" class="nav-item nav-link"><i class='bx bx-list-ul'></i> Daftar Transaksi</a>
                        <a href="laporan.php" class="nav-item nav-link"><i class='icon bx bx-book'></i> Laporan</a>
                    <?php } else if ($_SESSION["akses"] == 2) { ?>
                        <a href="index.php" class="nav-item nav-link active"><i class='icon bx bx-home-alt-2'></i> Home</a>
                        <a href="daftartransaksi.php" class="nav-item nav-link"><i class='bx bx-list-ul'></i> Daftar Transaksi</a>
                    <?php } ?>
                    <a href="../proses/proses_logout.php" class="btn nav-login nav-item nav-link d-flex align-items-center"><small>Logout</small><i class='icon bx bx-log-in-circle'></i></a>
                </div>
            </div>
        </div>
    </nav>




    <div class="produk" style="background-color:white; padding:20px;">

        <div class="container mt-2 mb-2 d-flex align-items-center justify-content-center">
            <span style="font-size:30px; font-weight:bold;"> Produk</span>
        </div>

        <div class="container">
            <div class="container overflow-hidden text-center">
                <div class="row gy-5">
                    <?php
                    while ($data = mysqli_fetch_array($result)) {
                    ?>
                        <div class="col-4">
                            <div class="content">
                                <img src="../uploads/<?php echo $data["gambar_produk"]; ?> " alt="" style="width:200px">
                                <p style="font-weight:bold"><?php echo $data["nama_produk"]; ?> </p>
                                <p><?php echo $data["detail_produk"]; ?> </p>
                                <p class="text-danger">Rp. <?php echo $data["harga_sewa"]; ?> /hari</p>
                                <!-- Detail Button -->
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo $data["id_produk"]; ?>">Detail</button>
<!-- Modal for Product Detail -->
<div class="modal fade" id="detailModal<?php echo $data["id_produk"]; ?>" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="detailModalLabel">Detail Produk</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img src="../uploads/<?php echo $data["gambar_produk"]; ?>" alt="" style="width:100%; max-height:300px; object-fit:contain">
                <p><strong>Nama Produk:</strong> <?php echo $data["nama_produk"]; ?></p>
                <p><strong>Detail Produk:</strong> <?php echo $data["detail_produk"]; ?></p>
                <p><strong>Harga Sewa:</strong> Rp. <?php echo number_format($data["harga_sewa"], 0, ',', '.'); ?> /hari</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- End Modal -->
                                <!-- <button class="btn btn-warning text-white">Sewa</button> -->
                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $data["id_produk"]; ?>" data-bs-whatever="@mdo">Sewa</button>
                                <!-- MODAL SEWA -->
                                <div class="modal fade" id="exampleModal<?php echo $data["id_produk"]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Form Peminjaman</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="POST" action="konfirmasi.php">
                                                <div class="modal-body">
                                                    <div class="mb-3 ">
                                                        <img src="../uploads/<?php echo $data["gambar_produk"]; ?>" alt="" style="width:200px">
                                                        <p><b><?php echo $data["nama_produk"]; ?></b></p>
                                                        <p class="text-danger"><b>Rp. <?php echo $data["harga_sewa"]; ?> /hari</b></p>
                                                    </div>

                                                    <input type="hidden" value="<?php echo $data["id_produk"]; ?>" name="id_produk">
                                                    <input type="hidden" value="<?php echo $data["harga_sewa"]; ?>" name="harga">
                                                    <input type="hidden" value="<?php echo $idUser; ?>" name="id_user">
                                                    <div class="mb-3 ">
                                                        <label for="recipient-name" class="d-flex justify-content-start col-form-label">Lama Peminjaman</label>
                                                        <input type="number" class="form-control" name="durasipinjam" required>
                                                    </div>

                                                    <div class="mb-3 ">
                                                        <label for="recipient-name" class="d-flex justify-content-start col-form-label">Tanggal Peminjaman</label>
                                                        <input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam" required>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label for="recipient-name" class="d-flex justify-content-start col-form-label">Tanggal Pengembalian</label>
                                                        <input type="date" class="form-control" id="recipient-name" name="tgl_pengembalian">
                                                    </div>

                                                    <select class="form-select" name="pembayaran" required>
                                                        <option selected>Jenis Pembayaran</option>
                                                        <option value="transfer">Transfer</option>
                                                        <option value="cash">Bayar Ditempat</option>
                                                    </select>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" name="btnnext" class="btn btn-primary" id="next">Next</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!--END MODAL SEWA -->



                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script>
        $(document).ready(function() {
            $('#tabel-data').DataTable();
        });
    </script>
    <script type="text/javascript">
        window.onload = date_time('date_time');
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>

</html>