<?php 
include "../dataacces/config.php";

if (!$_SESSION["logged"]) {
    header("location:../home.php");
}

if($_SESSION["akses"] != 1)
{
    echo "<script>alert('Hanya admin yang memiliki Akses')</script>";
    echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
}


$viewPendaftar = "SELECT * FROM user";
$result = mysqli_query($koneksi, $viewPendaftar);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <title>Member | Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <script src="../script.js"></script>
</head>
<body>    
    <nav class="navbar navbar-expand-lg">
            <div class="container">
                <div class="d-flex align-item-center">
                    <!-- <img src="../img/logo.png" alt="" class="nav-logo"> -->
                    <a href="#" class="navbar-brand">Penyewaan Motor</a>
                </div>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
                    <?php 
                    if($_SESSION["akses"] == 1)
                    {
                    ?>
                        <a href="member.php" class="nav-item nav-link active"><i class='icon bx bx-user' ></i> Member</a>
                        <a href="produk.php" class="nav-item nav-link"><i class='bx bxs-camera'></i> Produk</a>

                        <a href="daftartransaksi.php" class="nav-item nav-link"><i class='bx bx-list-ul'></i> Daftar Transaksi</a>
                        <a href="laporan.php" class="nav-item nav-link"><i class='icon bx bx-book' ></i> Laporan</a>
                    <?php }else if($_SESSION["akses"] == 2){?>
                        <a href="index.php" class="nav-item nav-link active"><i class='icon bx bx-home-alt-2' ></i> Home</a>
                        <?php }?>
                        <a href="../proses/proses_logout.php" class="btn nav-login nav-item nav-link d-flex align-items-center"><small>Logout</small><i class='icon bx bx-log-in-circle'></i></a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="alert alert-light mt-4 d-flex justify-content-between align-items-center" role="alert">
                <div class="d-flex align-items-center">
                    <i class='bx bxs-camera-plus icon' style="font-size:50px; margin-right:10px" ></i>
                    <h5><span style="color:blue; font-weight:bold;">Penyewaan </span> Motor </h5>
                </div>
                <div class="d-flex align-items-center">
                    <i class='bx bx-time icon' style="font-size:20px; margin-right:10px"></i> 
                    <span id="date_time"></span>
                </div>
            </div>
            <div class="card mt-4">
                <h3 class="mt-3 mr-5" style="margin-left:20px"><span class="text-primary">Tabel</span> Member</h3>
                <div class="card-body">
                    <table id="tabel-data" class="table table-danger table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th style="text-align: right;">Nama Lengkap</th>
                                <th style="text-align: right;">No Telpon</th>
                                <th style="text-align: right;">Email</th>
                                <th style="text-align: right;">Jenis Kelamin</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php 
                            $noUrut=1;
                            while($data = mysqli_fetch_array($result)){
                        ?>
                             <tr>
                                <td><?php echo $noUrut++; ?></td>
                                <td style="text-align: right;"><?php echo $data["nama_depan"]; ?> <?php echo $data["nama_belakang"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["no_telpon"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["email"]; ?></td>
                                <td style="text-align: right;"><?php echo $data["jenis_kelamin"]; ?></td>
                                <td>
            
                                <a href="" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalDetail<?php echo $data["id_user"]; ?>"><i class='bx bx-show'></i> Detail</a>
                                        
                                <!-- Modal Detail -->
                                <div class="modal fade" id="modalDetail<?php echo $data["id_user"]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Detail Member</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="../proses/proses_input_kriteria.php" method="post">
                                        <div class="modal-body">
                                            <h5 class="text-primary">Biodata</h5>
                                            <div class="form-group row">
                                                <div class="col-sm-4">
                                                    <label>Nama Depan</label>
                                                </div>

                                                <div class="col-sm-8">
                                                    <input class="form-control" type="text" name="nama_depan" value="<?php echo $data["nama_depan"]; ?>">
                                                </div>
                                            </div><br>

                                            <div class="form-group row">
                                                <div class="col-sm-4">
                                                    <label>Nama Belakang</label>
                                                </div>

                                                <div class="col-sm-8">
                                                    <input class="form-control" type="text" name="nama_belakang" value="<?php echo $data["nama_belakang"]; ?>">
                                                </div>
                                            </div><br>

                                            <div class="form-group row">
                                                <div class="col-sm-4">
                                                    <label>Email</label>
                                                </div>

                                                <div class="col-sm-8">
                                                    <input class="form-control" type="text" name="email" value="<?php echo $data["email"]; ?>">
                                                </div>
                                            </div><br>

                                            <div class="form-group row">
                                                <div class="col-sm-4">
                                                    <label>No Telpon</label>
                                                </div>

                                                <div class="col-sm-8">
                                                    <input class="form-control" type="text" name="no_telpon" value="<?php echo $data["no_telpon"]; ?>">
                                                </div>
                                            </div><br>

                                            <div class="form-group row">
                                                <div class="col-sm-4">
                                                    <label>Jenis Kelamin</label>
                                                </div>

                                                <div class="col-sm-8">
                                                    <input class="form-control" type="text" name="jenis_kelamin" value="<?php echo $data["jenis_kelamin"]; ?>">
                                                </div>
                                            </div><br>

        
                                        </div><br>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php 
                        }
                    ?>        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script>
            $(document).ready(function(){
                $('#tabel-data').DataTable();
            });
        </script>
        <script type="text/javascript">window.onload = date_time('date_time');</script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="script.js"></script>
    </body>
    </html>