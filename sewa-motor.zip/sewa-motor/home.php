<?php 
include "dataacces/config.php";

$viewTingkatKepentingan = "SELECT * FROM produk";
$result = mysqli_query($koneksi, $viewTingkatKepentingan);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <div class="d-flex align-item-center">
                <a href="#" class="navbar-brand">Penyewaan Motor</a>
            </div>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">
                    <a href="home.php" class="nav-item nav-link text-white active"><i class='icon bx bx-home-alt-2'></i> Home</a>
                    <a class="btn nav-login nav-item nav-link" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class='icon bx bx-user'></i> Login</a>
                </div>
            </div>
        </div>
    </nav>

    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/1..jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/2..jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/3..jpg" class="d-block w-100" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <div class="produk" style="background-color:white; padding:20px;">
        <div class="container mt-2 mb-2 d-flex align-items-center justify-content-center">
            <span style="font-size:30px; font-weight:bold;"> Produk</span>
        </div>

        <div class="container">
            <div class="container overflow-hidden text-center">
                <div class="row gy-5">
                    <?php 
                        while($data = mysqli_fetch_array($result)){
                    ?>
                    <div class="col-4">
                        <div class="content">
                            <img src="uploads/<?php echo $data["gambar_produk"]; ?>" alt="" style="width:200px">
                            <p style="font-weight:bold"><?php echo $data["nama_produk"]; ?></p>
                            <p><?php echo $data["detail_produk"]; ?></p>
                            <p class="text-danger">Rp. <?php echo $data["harga_sewa"]; ?>  /hari</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo $data['id_produk']; ?>">Detail</button>
                            <button class="btn btn-warning text-white" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Sewa</button>
                        </div>
                    </div>

                    <!-- Modal Detail Produk -->
                    <div class="modal fade" id="detailModal<?php echo $data['id_produk']; ?>" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header text-center">
                                    <h5 class="modal-title" id="detailModalLabel"><?php echo $data['nama_produk']; ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <img src="uploads/<?php echo $data['gambar_produk']; ?>" alt="" style="width:100%">
                                    <p><?php echo $data['detail_produk']; ?></p>
                                    <p class="text-danger">Rp. <?php echo $data['harga_sewa']; ?> /hari</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        }
                    ?>
                </div>
            </div>
        </div>  
    </div> 

    <!-- Modal Login -->
    <div class="modal fade" id="staticBackdrop" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <center><h5 class="modal-title text-white" id="staticBackdropLabel">Login</h5></center>
                </div>
                <div class="modal-body">
                    <section id="form-login">
                        <div class="login">
                            <div>
                                <form action="proses/proses_login.php" method="post">
                                    <div class="header-login">
                                        <img src="img/logo.png" alt="" style="width:100px">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Username</label>
                                        <input type="text" class="form-control" name="username" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Password</label>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>
                                    <div class="form-button">
                                        <button class="btn-login btn" type="submit" name="Submit">Login</button>
                                    </div>
                                    <div class="form-link">
                                        <span><a href="" class="forgot-password">Forgot password?</a> | <a href="register.php" class="link-register">Register</a></span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
