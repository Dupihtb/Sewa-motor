<?php
function deleteTransaction($id) {
    // Include file konfigurasi database
    include "../dataacces/config.php";

    // Escape input untuk mencegah SQL Injection
    $id_safe = mysqli_real_escape_string($koneksi, $id);

    // Query untuk menghapus transaksi berdasarkan ID
    $query = "DELETE FROM transaksi WHERE id_transaksi = '$id_safe'";
    
    // Eksekusi query
    $result = mysqli_query($koneksi, $query);

    // Cek hasil eksekusi
    if ($result) {
        echo "<script>alert('Berhasil membatalkan transaksi!')</script>";
        echo "<script type='text/javascript'>window.location='../view/daftartransaksi.php'</script>";
    } else {
        echo "<script>alert('Gagal membatalkan transaksi.')</script>";
        echo "<script type='text/javascript'>window.location='../view/daftartransaksi.php'</script>";
    }
}
?>
