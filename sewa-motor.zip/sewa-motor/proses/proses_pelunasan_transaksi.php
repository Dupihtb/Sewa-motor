<?php
 include "../dataacces/config.php";

 
        $id = $_GET["id_transaksi"];
        $update = "UPDATE transaksi SET status_transaksi = 'berlangsung' WHERE id_transaksi = '$id'";

        $result = mysqli_query($koneksi, $update);

        if($result){
            echo "<script>alert('Transaksi berhasil diproses')</script>";
            echo "<script type='text/javascript'>window.location='../view/daftartransaksi.php'</script>";
        } 
    
?>