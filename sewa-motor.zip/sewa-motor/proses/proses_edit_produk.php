<?php
include "../dataacces/config.php";

// Function to update product
function updateProduct($id, $namaproduk, $jumlahproduk, $detailproduk, $hargasewa) {
    global $koneksi;

    // Prepare the update query
    $update = "UPDATE produk 
               SET nama_produk = '$namaproduk', 
                   jumlah_produk = '$jumlahproduk', 
                   detail_produk = '$detailproduk', 
                   harga_sewa = '$hargasewa' 
               WHERE id_produk = '$id'";

    // Execute the update query
    $result = mysqli_query($koneksi, $update);

    // Check if the update was successful
    if ($result) {
        echo "<script>alert('Data Produk Berhasil Di Update')</script>";
        echo "<script type='text/javascript'>window.location='../view/produk.php'</script>";
    } else {
        echo "<script>alert('Gagal Update Data Produk')</script>";
        echo "<script type='text/javascript'>window.location='../view/produk.php'</script>";
    }
}

// Check if form is submitted
if (isset($_POST['btnupdate'])) {
    // Get form input
    $id = $_POST["id_produk"];
    $namaproduk = $_POST["nama_produk"];
    $jumlahproduk = $_POST["jumlah_produk"];
    $detailproduk = $_POST["detail_produk"];
    $hargasewa = $_POST["harga_sewa"];

    // Call updateProduct function to update the product
    updateProduct($id, $namaproduk, $jumlahproduk, $detailproduk, $hargasewa);
}
?>
