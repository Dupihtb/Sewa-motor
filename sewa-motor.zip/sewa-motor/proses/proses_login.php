<?php 

    include "../dataacces/config.php";

    if (isset($_POST["Submit"])) {

        $username = $_POST["username"];
        $password = $_POST["password"];
        // $pass = md5($password);
        $sql = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";

        $query = mysqli_query($koneksi, $sql);
        $data = mysqli_fetch_array($query);

        if (mysqli_num_rows($query) == 0) 
        {
            	echo "<script>alert('Username atau password salah!')</script>";
	            echo "<script type='text/javascript'>window.location='../home.php'</script>";
        }
        else
        {
           if($data['akses'] == "admin")
           {
                $_SESSION["akses"] = 1;
                $_SESSION["halaman"] = "admin";
                $_SESSION["username"] = "$username";
                $_SESSION["logged"] = true;
                header("location:../view/member.php");
           }
           else if($data['akses'] == "member")
           {
                $_SESSION["akses"] = 2;
                $_SESSION["halaman"] = "member";
                $_SESSION["username"] = "$username";
                $_SESSION["logged"] = true;
                header("location:../view/index.php");
           }
       
        }
    } 

?>