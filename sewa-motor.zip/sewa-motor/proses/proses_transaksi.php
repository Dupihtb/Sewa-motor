<?php

    include "../dataacces/config.php";
    if (isset($_GET['btnkonfirmasi'])) {

        $id = $_GET["id_produk"];
        $tglpinjam = $_GET["tgl_pinjam"];
        $tglbalik = $_GET["tgl_pengembalian"];
        $idUser = $_GET["id_user"];
        $tglnow = date("Y-m-d h:i:sa");
        $totalbayar = $_GET["total_bayar"];
        $pembayaran = $_GET["pembayaran"];

        
        $insert = "INSERT INTO transaksi VALUES 
        (
            '',
            '$id',
            '$idUser', 
            '$tglpinjam',
            '$tglbalik',
            '$totalbayar',
            '$tglnow',
            '$pembayaran',
            'proses'
        )";

        $query = mysqli_query($koneksi, $insert);
        if ($query) {

            echo "<script>alert('Berhasil')</script>";
            echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
        } else {
            print_r("gagal register");
            die;
        }
    }
?>