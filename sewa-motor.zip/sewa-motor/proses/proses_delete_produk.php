<?php
include "../dataacces/config.php";

/**
 * Fungsi untuk menghapus data produk berdasarkan ID.
 *
 * @param mysqli $koneksi Koneksi ke database.
 * @param int $id_produk ID produk yang akan dihapus.
 * @return bool True jika penghapusan berhasil, false jika gagal.
 */
function hapusProduk(mysqli $koneksi, int $id_produk): bool {
    $id = mysqli_real_escape_string($koneksi, $id_produk);
    $query = "DELETE FROM produk WHERE id_produk = '$id'";
    return mysqli_query($koneksi, $query);
}

// Penggunaan fungsi
$id_produk = $_GET['id_produk'] ?? null;

if ($id_produk) {
    if (hapusProduk($koneksi, $id_produk)) {
        echo "<script>alert('Data Kriteria Berhasil Dihapus')</script>";
        echo "<script type='text/javascript'>window.location='../view/produk.php'</script>";
    } else {
        echo "<script>alert('Gagal menghapus data')</script>";
    }
} else {
    echo "<script>alert('ID Produk tidak ditemukan')</script>";
    echo "<script type='text/javascript'>window.location='../view/produk.php'</script>";
}
?>
