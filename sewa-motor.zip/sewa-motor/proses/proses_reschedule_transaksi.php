<?php
include "../dataacces/config.php";

if (isset($_POST['btnupdate'])) {
    $id = $_POST["id_transaksi"];
    $sewa = $_POST["tglsewa"];
    $balik = $_POST["tglbalik"];

    $update = "UPDATE transaksi SET tanggal_sewa = '$sewa', tgl_pengembalian='$balik' WHERE id_transaksi = '$id'";

    $result = mysqli_query($koneksi, $update);

    if ($result) {
        echo "<script>alert('Berhasil reshedule')</script>";
        echo "<script type='text/javascript'>window.location='../view/daftartransaksi.php'</script>";
    }
}
