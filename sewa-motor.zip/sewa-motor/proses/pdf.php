<?php
// Function to generate a PDF report of completed transactions
function generateTransactionReport($koneksi) {
    // Load FPDF library
    require('../pdf/fpdf.php');
    
    // Initialize PDF with settings
    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->SetMargins(25, 20, 20, 20);
    $pdf->SetAutoPageBreak(true, 30);

    // Add a new page to the PDF
    $pdf->AddPage();
    
    // Set the font for the title
    $pdf->SetFont('Arial', 'B', 12);
    // Center the title
    $pdf->Cell(0, 11, 'Laporan Transaksi', 0, 1, 'C');
    
    // Add a space before the table
    $pdf->Cell(10, 7, '', 0, 1);

    // Set table header
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(7, 6, 'No', 1, 0);
    $pdf->Cell(50, 6, 'Nama Produk', 1, 0);
    $pdf->Cell(50, 6, 'Tanggal', 1, 0);
    $pdf->Cell(25, 6, 'Total Bayar', 1, 0);
    $pdf->Cell(25, 6, 'Peminjam', 1, 1);

    // Set font for table content
    $pdf->SetFont('Arial', '', 10);

    // Query the database for completed transactions
    $query = "SELECT *
              FROM ((transaksi
              INNER JOIN produk ON produk.id_produk = transaksi.id_produk)
              INNER JOIN user ON user.id_user = transaksi.id_user)
              WHERE status_transaksi='selesai'";
    $berkas = mysqli_query($koneksi, $query);
    
    // Check if query was successful
    if (!$berkas) {
        die("Query Error: " . mysqli_error($koneksi));
    }

    // Add rows to the table
    $no = 1;
    while ($row = mysqli_fetch_array($berkas)) {
        $pdf->Cell(7, 6, $no++, 1, 0);
        $pdf->Cell(50, 6, $row['nama_produk'], 1, 0);
        $pdf->Cell(50, 6, $row['tgl_transaksi'], 1, 0);
        $pdf->Cell(25, 6, $row['harga_total'], 1, 0);  
        $pdf->Cell(25, 6, $row['nama_depan'], 1, 1);
    }

    // Output the generated PDF
    $pdf->Output();
}

// Usage
include "../dataacces/config.php";
generateTransactionReport($koneksi);
?>
