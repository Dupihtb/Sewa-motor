<?php
           include "../dataacces/config.php";


            if(isset($_POST['btnregister'])){
                $nama = $_POST["nama_depan"];
                $namabelakang = $_POST["nama_belakang"];
                $email = $_POST["email"];
                $notelpon = $_POST["no_telpon"];
                $jeniskelamin = $_POST["jenis_kelamin"];
              
                $username =  $_POST["username"];
                $pass =  $_POST["password"];
          

                $insert = "INSERT INTO user VALUES 
                (
                    '',
                    '$nama', 
                    '$namabelakang',
                    '$email',
                    '$notelpon',
                    '$jeniskelamin'
                )";

                $query = mysqli_query($koneksi, $insert);

                if ($query) {

                    $viewLastData = "SELECT id_user FROM user ORDER BY id_user DESC LIMIT 1";
                    $query = mysqli_query($koneksi, $viewLastData);
                    $row = mysqli_fetch_array($query);
                    $idNow = $row["id_user"];        

                    $insertAccount = "INSERT INTO login VALUES 
                    (
                        '',
                        '$username',
                        '$pass',
                        'member',
                        '$idNow'
                    )";

                    $query2 = mysqli_query($koneksi, $insertAccount);

                    echo "<script>alert('Berhasil Register')</script>";
                    echo "<script type='text/javascript'>window.location='../home.php'</script>";
                } else {
                    print_r("gagal register");
                    die;
                }
    
            }

?>