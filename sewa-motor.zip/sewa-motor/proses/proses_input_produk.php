<?php
include "../dataacces/config.php";

// Function to add product
function addProduct($namaproduk, $jumlahproduk, $detailproduk, $hargasewa, $fileBerkas) {
    global $koneksi;

    // Allowed file extensions and max size
    $ekstensi_diperbolehkan = array('jpg', 'png');
    $x = explode('.', $fileBerkas['name']);
    $ekstensi = strtolower(end($x));
    $ukuran = $fileBerkas['size'];
    $file_tmp = $fileBerkas['tmp_name'];

    // File validation
    if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
        if ($ukuran < 1044070) {
            // Move file to uploads folder
            $filePath = '../uploads/' . $fileBerkas['name'];
            move_uploaded_file($file_tmp, $filePath);

            // Insert product details into the database
            $insert = "INSERT INTO produk (id_produk, nama_produk, jumlah_produk, detail_produk, harga_sewa, gambar_produk) 
                       VALUES ('', '$namaproduk', '$jumlahproduk', '$detailproduk', '$hargasewa', '$fileBerkas[name]')";
            $query = mysqli_query($koneksi, $insert);

            // Check if query was successful
            if ($query) {
                echo "<script>alert('Berhasil Tambah Produk')</script>";
                echo "<script type='text/javascript'>window.location='../view/produk.php'</script>";
            } else {
                echo "<script>alert('Gagal Upload berkas')</script>";
                echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
            }
        } else {
            echo "<script>alert('Ukuran Terlalu Besar')</script>";
            echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
        }
    } else {
        echo "<script>alert('Ekstensi tidak diperbolehkan')</script>";
        echo "<script type='text/javascript'>window.location='../view/index.php'</script>";
    }
}

// Check if form is submitted
if (isset($_POST['btnsubmit'])) {
    // Get form input
    $namaproduk = $_POST["nama_produk"];
    $jumlahproduk = $_POST["jumlah_produk"];
    $detailproduk = $_POST["detail_produk"];
    $hargasewa = $_POST["harga_sewa"];
    $fileBerkas = $_FILES['gambar_produk'];

    // Call addProduct function to add the product
    addProduct($namaproduk, $jumlahproduk, $detailproduk, $hargasewa, $fileBerkas);
}
?>
